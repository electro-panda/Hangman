import random

f=open("words.txt","r")
data= f.readline()
words=data.split()
word=random.choice(words)
word= word.upper()
Chances=7
guessed_word="_"*len(word)
print(guessed_word)
while(Chances !=0):
    letter=input("Guess a Letter:").upper()
    if letter in word:
        for index in range(len(word)):
            if word[index]==letter:
                guessed_word=guessed_word[:index]+letter+guessed_word[index+1:]
                print(guessed_word)
        if guessed_word == word:
            print("Congratulations You Won!!!")
            break
    else:
        Chances-=1
        print("Incorrect Guess")
        print("Remaining chances are:",Chances)
if(Chances == 0):
    print("Game Over")
    print("You Lose!!!")
    print("All the chances are finished")
print("The correct word is:",word)